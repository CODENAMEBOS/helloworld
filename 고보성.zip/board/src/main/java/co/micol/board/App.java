package co.micol.board;

import co.micol.board.main.MainMenu;

public class App {
	public static void main(String[] args) {
		MainMenu menu = new MainMenu();
		menu.run();
	}
}
